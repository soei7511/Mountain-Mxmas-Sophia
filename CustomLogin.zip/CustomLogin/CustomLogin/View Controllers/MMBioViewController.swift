//
//  MMBioViewController.swift
//  CustomLogin
//
//  Created by Sophia Tea Eisner on 2/3/21.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseStorage

class MMBioViewController: UIViewController {
    
    @IBOutlet weak var profileTitle: UILabel!
    
    @IBOutlet weak var location: UILabel!
    
    @IBOutlet weak var pronouns: UILabel!

    @IBOutlet weak var profileImg: UIImageView!
    
    @IBOutlet weak var bioText: UILabel!
    
    //refernece to storage service
    let storage = Storage.storage()
    
    
    func displayImage(){
        //reference
        let gsRef = storage.reference(forURL: "gs://customlogin-7a5f7.appspot.com/images/B347C668-8D90-4699-B89F-7B79E1BEFAA3.jpeg")
        
        gsRef.getData(maxSize: 1 * 5120 * 5120) {data, error in
            if let error = error {
              // Uh-oh, an error occurred!
                print("error grabbing image")
            } else {
              // Data for image is returned
                self.profileImg.image = UIImage(data: data!)
                //self.profileImg.image = UIImage(data: data!)
            }
        }
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        generateBio()
        displayImage()
        // Do any additional setup after loading the view.
    }
 
    func generateBio(){
        let db = Firestore.firestore()
        
        //get UID of current user
        guard let userID = Auth.auth().currentUser?.uid else {return}
                
        let docRef = db.collection("users").document(userID)
        
        //retreive contents of document from current userID
        docRef.getDocument { (document, error) in
            if let document = document, document.exists {
                
                //get first name
                let firstName = document.get("firstname") as! String
                print("name: \(firstName)")
                
                //get location
                let userLoc = document.get("location") as! String
                
                //get pronouns
                let pn = document.get("pronouns") as! String
                
                //get bio
                let bio = document.get("bio") as! String
                
                //Update labels on profile
                self.profileTitle.text = firstName
                self.pronouns.text = pn
                self.location.text = userLoc
                self.bioText.text = bio
                
            } else {
                print("Document does not exist")
            }
        }
        
    }
    
}

