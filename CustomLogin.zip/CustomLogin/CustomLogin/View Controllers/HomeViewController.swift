//
//  HomeViewController.swift
//  CustomLogin
//
//  Created by Sophia Tea Eisner on 1/26/21.
//

import UIKit

class HomeViewController: UIViewController {
    
    
    @IBOutlet weak var pressToContinue: UIButton!
    
    
    @IBOutlet weak var MmLogo: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    
}
