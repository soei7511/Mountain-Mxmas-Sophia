//
//  BioViewController.swift
//  CustomLogin
//
//  Created by Sophia Tea Eisner on 2/3/21.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore

class BioViewController: UIViewController {

    @IBOutlet weak var BioTextField: UITextField!
    
    @IBOutlet weak var ProfileLabel: UILabel!
    
    @IBOutlet weak var AboutLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    //Check fields and validate that the data is correct. If everything is correct, method returns nil. Otherwrise, returns error message
    func validateFields() -> String? {
        
        //Check that fields are filled in
        if BioTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
            return "Please fill in bio."
        }
        return nil
    }
    
    @IBAction func UpdateBio(_ sender: Any) {
        
        //Validate fields
        let error = validateFields()
        
        if error != nil {
            // There is something wrong with the fields, show error message
            print("error validating fields")
        }
        
        let db = Firestore.firestore()
        
        //get UID of current user
        guard let userID = Auth.auth().currentUser?.uid else {return}
        
        //Get cleaned bio
        let bio = BioTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        
        
        db.collection("users").document(userID).setData([
            "bio": bio
        ]) { err in
            if let err = err {
                print("Error writing document: \(err)")
            } else {
                print("Document successfully written!")
            }
        }


        
        
    }
 
    

}
