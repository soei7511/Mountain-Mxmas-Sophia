//
//  CreateBioViewController.swift
//  CustomLogin
//
//  Created by Sophia Tea Eisner on 2/3/21.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore

class CreateBioViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource{
    
    @IBOutlet weak var PronounsPicker: UIPickerView!
    
    @IBOutlet weak var BioName: UILabel!
        
    @IBOutlet weak var bioText: UITextField!
    
    @IBOutlet weak var userLocation: UITextField!
    
    var pickerData: [String] = [String]()
    var selectedPicker = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //add rounded border to bio text field
        bioText.borderStyle = UITextField.BorderStyle.roundedRect
        
        //Connect data:
        self.PronounsPicker.delegate = self
        self.PronounsPicker.dataSource = self
        
        pickerData = ["They/them", "She/her", "He/him"]
        selectedPicker = pickerData[0]
    }
    
    //number of columns of picker
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    //number of rows of picker
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    //data to return that's being passed in
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        selectedPicker = pickerData[row]
        return pickerData[row]
    }
    
    
    func setUpBioInfo(){
        
        let db = Firestore.firestore()
        
        //get UID of current user
        guard let userID = Auth.auth().currentUser?.uid else {return}
        
        //Get cleaned bio and location
        let bio = bioText.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let location = userLocation.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        
        //Get pronouns
        let pn = selectedPicker
                
        let docRef = db.collection("users").document(userID)
        
        //update user data to include pronouns and bio
        docRef.updateData(["pronouns": pn, "bio": bio, "location": location])
        { err in
            if let err = err {
                print("Error writing document: \(err)")
            } else {
                print("Document successfully written!")
            }
        }

        
        //retreive contents of document from current userID
        docRef.getDocument { (document, error) in
            if let document = document, document.exists {
                let firstName = document.get("firstname") as! String
                print("name: \(firstName)")
                
                //let pronouns = document.get("pronouns") as! String
                
                //Add user's name to profile view
                //self.BioName.text = (firstName+"'s Profile")
                
                //Add user's pronouns to profile view
                //self.userPronouns.text = ("Pronouns: " + pronouns)
                
                
            } else {
                print("Document does not exist")
            }
        }
        
    }
    
    
    @IBAction func CreateProfileOnTap(_ sender: Any) {
        
        setUpBioInfo()
        let viewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MMBioViewController") as! MMBioViewController
        self.navigationController?.pushViewController(viewController, animated: true)
        self.present(viewController, animated: true, completion: nil)
    }
    

}
